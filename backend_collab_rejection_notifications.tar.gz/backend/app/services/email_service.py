from flask import current_app
from flask_mail import Message
from app import mail
from threading import Thread


def send_async_email(app, msg):
    """Send email asynchronously"""
    with app.app_context():
        mail.send(msg)


def send_email(subject, recipients, text_body, html_body=None):
    """Send email"""
    msg = Message(
        subject=subject,
        recipients=recipients if isinstance(recipients, list) else [recipients],
        sender=current_app.config['MAIL_DEFAULT_SENDER']
    )
    msg.body = text_body
    if html_body:
        msg.html = html_body

    # Send asynchronously
    Thread(target=send_async_email, args=(current_app._get_current_object(), msg)).start()


def send_otp_email(email, otp_code, purpose='registration'):
    """Send OTP verification email"""
    purpose_text = {
        'registration': 'verify your account',
        'password_reset': 'reset your password',
        'email_change': 'change your email'
    }.get(purpose, 'verify your account')

    subject = f"Your BantuBuzz verification code: {otp_code}"
    text_body = f"""
    Welcome to BantuBuzz!

    Your verification code is: {otp_code}

    Please enter this code to {purpose_text}.
    This code will expire in 10 minutes.

    If you did not request this code, please ignore this email.

    Best regards,
    The BantuBuzz Team
    """

    html_body = f"""
    <html>
    <body style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <div style="background-color: #B5E61D; padding: 20px; text-align: center;">
            <h1 style="color: #1F2937; margin: 0;">BantuBuzz</h1>
        </div>
        <div style="padding: 30px; background-color: #F3F4F6;">
            <h2 style="color: #1F2937;">Your Verification Code</h2>
            <p style="color: #1F2937; line-height: 1.6;">
                Thank you for joining Africa's premier creator-brand collaboration platform.
                Please use the code below to {purpose_text}.
            </p>
            <div style="text-align: center; margin: 30px 0;">
                <div style="background-color: #1F2937; color: #B5E61D; padding: 20px 40px;
                            font-size: 32px; font-weight: bold; letter-spacing: 8px;
                            border-radius: 10px; display: inline-block;">
                    {otp_code}
                </div>
            </div>
            <p style="color: #F59E0B; font-size: 14px; text-align: center;">
                This code will expire in 10 minutes.
            </p>
            <p style="color: #6B7280; font-size: 14px;">
                If you did not request this code, please ignore this email.
            </p>
        </div>
        <div style="background-color: #1F2937; padding: 20px; text-align: center;">
            <p style="color: #F3F4F6; margin: 0; font-size: 14px;">
                © 2025 BantuBuzz. All rights reserved.
            </p>
        </div>
    </body>
    </html>
    """

    send_email(subject, email, text_body, html_body)


def send_verification_email(email, token):
    """Send email verification"""
    frontend_url = current_app.config['FRONTEND_URL']
    verification_url = f"{frontend_url}/verify-email/{token}"

    subject = "Verify your BantuBuzz account"
    text_body = f"""
    Welcome to BantuBuzz!

    Please verify your email address by clicking the link below:
    {verification_url}

    If you did not create an account, please ignore this email.

    Best regards,
    The BantuBuzz Team
    """

    html_body = f"""
    <html>
    <body style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <div style="background-color: #B5E61D; padding: 20px; text-align: center;">
            <h1 style="color: #1F2937; margin: 0;">BantuBuzz</h1>
        </div>
        <div style="padding: 30px; background-color: #F3F4F6;">
            <h2 style="color: #1F2937;">Welcome to BantuBuzz!</h2>
            <p style="color: #1F2937; line-height: 1.6;">
                Thank you for joining Africa's premier creator-brand collaboration platform.
                Please verify your email address to get started.
            </p>
            <div style="text-align: center; margin: 30px 0;">
                <a href="{verification_url}"
                   style="background-color: #B5E61D; color: #1F2937; padding: 12px 30px;
                          text-decoration: none; border-radius: 5px; font-weight: bold;">
                    Verify Email Address
                </a>
            </div>
            <p style="color: #6B7280; font-size: 14px;">
                If you did not create an account, please ignore this email.
            </p>
        </div>
        <div style="background-color: #1F2937; padding: 20px; text-align: center;">
            <p style="color: #F3F4F6; margin: 0; font-size: 14px;">
                © 2025 BantuBuzz. All rights reserved.
            </p>
        </div>
    </body>
    </html>
    """

    send_email(subject, email, text_body, html_body)


def send_password_reset_email(email, token):
    """Send password reset email"""
    frontend_url = current_app.config['FRONTEND_URL']
    reset_url = f"{frontend_url}/reset-password/{token}"

    subject = "Reset your BantuBuzz password"
    text_body = f"""
    You requested to reset your password.

    Click the link below to reset your password:
    {reset_url}

    This link will expire in 1 hour.

    If you did not request a password reset, please ignore this email.

    Best regards,
    The BantuBuzz Team
    """

    html_body = f"""
    <html>
    <body style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <div style="background-color: #B5E61D; padding: 20px; text-align: center;">
            <h1 style="color: #1F2937; margin: 0;">BantuBuzz</h1>
        </div>
        <div style="padding: 30px; background-color: #F3F4F6;">
            <h2 style="color: #1F2937;">Password Reset Request</h2>
            <p style="color: #1F2937; line-height: 1.6;">
                You requested to reset your password. Click the button below to create a new password.
            </p>
            <div style="text-align: center; margin: 30px 0;">
                <a href="{reset_url}"
                   style="background-color: #B5E61D; color: #1F2937; padding: 12px 30px;
                          text-decoration: none; border-radius: 5px; font-weight: bold;">
                    Reset Password
                </a>
            </div>
            <p style="color: #F59E0B; font-size: 14px;">
                This link will expire in 1 hour.
            </p>
            <p style="color: #6B7280; font-size: 14px;">
                If you did not request a password reset, please ignore this email.
            </p>
        </div>
        <div style="background-color: #1F2937; padding: 20px; text-align: center;">
            <p style="color: #F3F4F6; margin: 0; font-size: 14px;">
                © 2025 BantuBuzz. All rights reserved.
            </p>
        </div>
    </body>
    </html>
    """

    send_email(subject, email, text_body, html_body)


def send_booking_confirmation_email(booking, brand_email, creator_email):
    """Send booking confirmation to both parties"""
    subject = f"New Booking Confirmation - {booking.package.title}"

    # Email to brand
    brand_text = f"""
    Your booking has been confirmed!

    Package: {booking.package.title}
    Amount: ${booking.amount}
    Booking ID: {booking.id}

    The creator will be notified and will start working on your project.

    Best regards,
    The BantuBuzz Team
    """

    # Email to creator
    creator_text = f"""
    You have a new booking!

    Package: {booking.package.title}
    Amount: ${booking.amount}
    Booking ID: {booking.id}

    Please log in to your dashboard to view the details and get started.

    Best regards,
    The BantuBuzz Team
    """

    send_email(subject, brand_email, brand_text)
    send_email(subject, creator_email, creator_text)


def send_collaboration_declined_email(brand_email, brand_name, creator_name, collaboration_title, refund_amount, decline_reason, counter_offer=None):
    """Send email notification when creator declines a collaboration"""
    frontend_url = current_app.config.get('FRONTEND_URL', 'https://bantubuzz.com')

    subject = f"Collaboration Declined - {collaboration_title}"

    counter_offer_text = ""
    counter_offer_html = ""
    if counter_offer:
        counter_offer_text = f"\n\nCounter Offer:\n  Amount: ${counter_offer.get('amount')}\n  Duration: {counter_offer.get('duration')} days\n  Details: {counter_offer.get('details', 'N/A')}"
        counter_offer_html = f"""
            <div style="background-color: #FEF3C7; padding: 20px; border-radius: 8px; margin: 20px 0; border-left: 4px solid #F59E0B;">
                <h3 style="color: #92400E; margin-top: 0;">Counter Offer Available</h3>
                <p style="margin: 10px 0;"><strong>Amount:</strong> ${counter_offer.get('amount')}</p>
                <p style="margin: 10px 0;"><strong>Duration:</strong> {counter_offer.get('duration')} days</p>
                <p style="margin: 10px 0;"><strong>Details:</strong> {counter_offer.get('details', 'N/A')}</p>
                <div style="text-align: center; margin-top: 15px;">
                    <a href="{frontend_url}/brand/wallet"
                       style="background-color: #F59E0B; color: white; padding: 10px 24px;
                              text-decoration: none; border-radius: 5px; font-weight: bold; display: inline-block;">
                        View Counter Offer
                    </a>
                </div>
            </div>
        """

    text_body = f"""
    Hello {brand_name},

    We're writing to inform you that {creator_name} has declined your collaboration request for "{collaboration_title}".

    Decline Reason:
    {decline_reason}{counter_offer_text}

    Refund Information:
    The full amount of ${refund_amount:.2f} has been automatically refunded to your BantuBuzz wallet and is available for immediate use.

    Next Steps:
    - You can browse other creators and packages on our platform
    - Consider reaching out to other creators who match your campaign needs
    - Check your wallet to confirm the refund

    View Your Wallet: {frontend_url}/brand/wallet

    If you have any questions or need assistance finding the right creator for your campaign, our support team is here to help.

    Best regards,
    The BantuBuzz Team
    """

    html_body = f"""
    <html>
    <body style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; background-color: #F9FAFB;">
        <div style="background-color: #B5E61D; padding: 20px; text-align: center;">
            <h1 style="color: #1F2937; margin: 0;">BantuBuzz</h1>
        </div>
        <div style="padding: 30px; background-color: white;">
            <h2 style="color: #1F2937;">Collaboration Declined</h2>
            <p style="color: #1F2937; line-height: 1.6;">
                Hello {brand_name},
            </p>
            <p style="color: #1F2937; line-height: 1.6;">
                We're writing to inform you that <strong>{creator_name}</strong> has declined your collaboration request for <strong>"{collaboration_title}"</strong>.
            </p>

            <div style="background-color: #FEE2E2; padding: 20px; border-radius: 8px; margin: 20px 0; border-left: 4px solid #DC2626;">
                <h3 style="color: #991B1B; margin-top: 0;">Decline Reason</h3>
                <p style="color: #7F1D1D; margin: 0;">{decline_reason}</p>
            </div>

            {counter_offer_html}

            <div style="background-color: #D1FAE5; padding: 20px; border-radius: 8px; margin: 20px 0; border-left: 4px solid #10B981;">
                <h3 style="color: #065F46; margin-top: 0;">✓ Refund Processed</h3>
                <p style="color: #064E3B; margin: 10px 0;">
                    The full amount of <strong>${refund_amount:.2f}</strong> has been automatically refunded to your BantuBuzz wallet and is available for immediate use.
                </p>
                <div style="text-align: center; margin-top: 15px;">
                    <a href="{frontend_url}/brand/wallet"
                       style="background-color: #10B981; color: white; padding: 10px 24px;
                              text-decoration: none; border-radius: 5px; font-weight: bold; display: inline-block;">
                        View Wallet
                    </a>
                </div>
            </div>

            <div style="background-color: #F3F4F6; padding: 20px; border-radius: 8px; margin: 20px 0;">
                <h3 style="color: #1F2937; margin-top: 0;">What's Next?</h3>
                <ul style="color: #4B5563; line-height: 1.8;">
                    <li>Browse other creators and packages on our platform</li>
                    <li>Consider reaching out to other creators who match your campaign needs</li>
                    <li>Your refunded amount is ready to use for new bookings</li>
                </ul>
                <div style="text-align: center; margin-top: 15px;">
                    <a href="{frontend_url}/brand/discover"
                       style="background-color: #B5E61D; color: #1F2937; padding: 10px 24px;
                              text-decoration: none; border-radius: 5px; font-weight: bold; display: inline-block;">
                        Discover Creators
                    </a>
                </div>
            </div>

            <p style="color: #6B7280; font-size: 14px; margin-top: 30px;">
                If you have any questions or need assistance finding the right creator for your campaign, our support team is here to help.
            </p>
        </div>
        <div style="background-color: #1F2937; padding: 20px; text-align: center;">
            <p style="color: #F3F4F6; margin: 0; font-size: 14px;">
                © 2025 BantuBuzz. All rights reserved.
            </p>
        </div>
    </body>
    </html>
    """

    send_email(subject, brand_email, text_body, html_body)
