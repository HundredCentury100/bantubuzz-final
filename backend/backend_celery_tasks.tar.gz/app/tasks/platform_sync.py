"""
Platform synchronization background tasks.

These tasks handle periodic syncing of platform data from ThunziAI
and other social media APIs to keep creator analytics up to date.
"""
from app.celery_app import celery
from app.models.creator import Creator
from app.models.platform import Platform
from app.services.thunzi_service import ThunziService
from app.extensions import db
from datetime import datetime, timedelta
from sqlalchemy import and_
import logging

logger = logging.getLogger(__name__)


@celery.task(name='app.tasks.platform_sync.sync_platform')
def sync_platform(platform_id):
    """
    Sync a single platform's data from ThunziAI.

    Args:
        platform_id: ID of the platform to sync

    Returns:
        dict: Sync result with status and data
    """
    try:
        logger.info(f"Starting sync for platform {platform_id}")

        platform = Platform.query.get(platform_id)
        if not platform:
            logger.error(f"Platform {platform_id} not found")
            return {'status': 'error', 'message': 'Platform not found'}

        # Check if platform is connected
        if not platform.is_connected:
            logger.warning(f"Platform {platform_id} is not connected")
            return {'status': 'skipped', 'message': 'Platform not connected'}

        # Initialize ThunziAI service
        thunzi_service = ThunziService()

        # Sync platform data based on type
        if platform.platform == 'instagram':
            result = thunzi_service.sync_instagram_platform(
                platform_id=platform.thunzi_platform_id,
                access_token=platform.access_token
            )
        elif platform.platform == 'facebook':
            result = thunzi_service.sync_facebook_platform(
                platform_id=platform.thunzi_platform_id,
                access_token=platform.access_token
            )
        elif platform.platform == 'tiktok':
            result = thunzi_service.sync_tiktok_platform(
                platform_id=platform.thunzi_platform_id,
                access_token=platform.access_token
            )
        elif platform.platform == 'youtube':
            result = thunzi_service.sync_youtube_platform(
                platform_id=platform.thunzi_platform_id,
                access_token=platform.access_token
            )
        else:
            logger.warning(f"Unsupported platform type: {platform.platform}")
            return {'status': 'skipped', 'message': f'Unsupported platform type: {platform.platform}'}

        # Update last synced timestamp
        platform.last_synced = datetime.utcnow()
        db.session.commit()

        logger.info(f"Successfully synced platform {platform_id}")
        return {
            'status': 'success',
            'platform_id': platform_id,
            'platform': platform.platform,
            'synced_at': platform.last_synced.isoformat(),
            'result': result
        }

    except Exception as e:
        logger.error(f"Error syncing platform {platform_id}: {str(e)}", exc_info=True)
        return {
            'status': 'error',
            'platform_id': platform_id,
            'message': str(e)
        }


@celery.task(name='app.tasks.platform_sync.sync_creator_platforms')
def sync_creator_platforms(creator_id):
    """
    Sync all platforms for a specific creator.

    Args:
        creator_id: ID of the creator

    Returns:
        dict: Sync results for all platforms
    """
    try:
        logger.info(f"Starting platform sync for creator {creator_id}")

        creator = Creator.query.get(creator_id)
        if not creator:
            logger.error(f"Creator {creator_id} not found")
            return {'status': 'error', 'message': 'Creator not found'}

        platforms = Platform.query.filter_by(
            creator_id=creator_id,
            is_connected=True
        ).all()

        if not platforms:
            logger.info(f"No connected platforms found for creator {creator_id}")
            return {
                'status': 'success',
                'creator_id': creator_id,
                'message': 'No connected platforms to sync',
                'platforms': []
            }

        results = []
        for platform in platforms:
            result = sync_platform.delay(platform.id)
            results.append({
                'platform_id': platform.id,
                'platform': platform.platform,
                'task_id': result.id
            })

        logger.info(f"Queued {len(results)} platform sync tasks for creator {creator_id}")
        return {
            'status': 'success',
            'creator_id': creator_id,
            'platforms_queued': len(results),
            'tasks': results
        }

    except Exception as e:
        logger.error(f"Error syncing creator platforms {creator_id}: {str(e)}", exc_info=True)
        return {
            'status': 'error',
            'creator_id': creator_id,
            'message': str(e)
        }


@celery.task(name='app.tasks.platform_sync.sync_all_platforms')
def sync_all_platforms():
    """
    Periodic task to sync all connected platforms across all creators.

    This runs every 6 hours to keep platform data fresh.

    Returns:
        dict: Summary of sync operations
    """
    try:
        logger.info("Starting periodic sync for all platforms")

        # Get all connected platforms that haven't been synced in the last 6 hours
        six_hours_ago = datetime.utcnow() - timedelta(hours=6)

        platforms = Platform.query.filter(
            and_(
                Platform.is_connected == True,
                db.or_(
                    Platform.last_synced == None,
                    Platform.last_synced < six_hours_ago
                )
            )
        ).all()

        logger.info(f"Found {len(platforms)} platforms to sync")

        # Queue sync tasks for each platform
        tasks = []
        for platform in platforms:
            result = sync_platform.delay(platform.id)
            tasks.append({
                'platform_id': platform.id,
                'platform': platform.platform,
                'creator_id': platform.creator_id,
                'task_id': result.id
            })

        logger.info(f"Queued {len(tasks)} platform sync tasks")
        return {
            'status': 'success',
            'platforms_queued': len(tasks),
            'tasks': tasks,
            'timestamp': datetime.utcnow().isoformat()
        }

    except Exception as e:
        logger.error(f"Error in periodic platform sync: {str(e)}", exc_info=True)
        return {
            'status': 'error',
            'message': str(e),
            'timestamp': datetime.utcnow().isoformat()
        }


@celery.task(name='app.tasks.platform_sync.cleanup_old_sync_results')
def cleanup_old_sync_results():
    """
    Clean up old Celery task results.

    This runs daily to prevent the results backend from growing too large.

    Returns:
        dict: Cleanup summary
    """
    try:
        logger.info("Starting cleanup of old task results")

        # Celery automatically handles this with result_expires setting
        # This task is mainly for logging and future custom cleanup logic

        logger.info("Cleanup completed")
        return {
            'status': 'success',
            'message': 'Cleanup completed',
            'timestamp': datetime.utcnow().isoformat()
        }

    except Exception as e:
        logger.error(f"Error in cleanup task: {str(e)}", exc_info=True)
        return {
            'status': 'error',
            'message': str(e),
            'timestamp': datetime.utcnow().isoformat()
        }
