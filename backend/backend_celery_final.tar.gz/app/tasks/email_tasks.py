"""
Email sending background tasks.

These tasks handle asynchronous email sending to avoid blocking HTTP requests.
"""
from app.celery_app import celery
from app.services import email_service
import logging

logger = logging.getLogger(__name__)


@celery.task(name='app.tasks.email_tasks.send_email')
def send_email_task(subject, recipients, text_body, html_body=None):
    """
    Send an email asynchronously.

    Args:
        subject: Email subject
        recipients: Recipient email address or list of addresses
        text_body: Plain text email body
        html_body: HTML email body (optional)

    Returns:
        dict: Send result
    """
    try:
        logger.info(f"Sending email to {recipients}: {subject}")

        email_service.send_email(
            subject=subject,
            recipients=recipients,
            text_body=text_body,
            html_body=html_body
        )

        logger.info(f"Successfully sent email to {recipients}")
        return {
            'status': 'success',
            'to': recipients,
            'subject': subject
        }

    except Exception as e:
        logger.error(f"Error sending email to {recipients}: {str(e)}", exc_info=True)
        return {
            'status': 'error',
            'to': recipients,
            'message': str(e)
        }


@celery.task(name='app.tasks.email_tasks.send_collaboration_notification')
def send_collaboration_notification(collaboration_id, notification_type):
    """
    Send collaboration-related notification email.

    Args:
        collaboration_id: ID of the collaboration
        notification_type: Type of notification (new, accepted, rejected, completed, etc.)

    Returns:
        dict: Send result
    """
    try:
        from app.models import Collaboration, CreatorProfile, BrandProfile

        logger.info(f"Sending {notification_type} notification for collaboration {collaboration_id}")

        collaboration = Collaboration.query.get(collaboration_id)
        if not collaboration:
            logger.error(f"Collaboration {collaboration_id} not found")
            return {'status': 'error', 'message': 'Collaboration not found'}

        creator = CreatorProfile.query.get(collaboration.creator_id)
        brand = BrandProfile.query.get(collaboration.brand_id)

        # Determine recipient and email content based on notification type
        if notification_type == 'new':
            # Notify creator of new collaboration request
            to_email = creator.user.email
            subject = f"New Collaboration Request from {brand.company_name}"
            body = f"You have a new collaboration request from {brand.company_name}. Log in to view details."

        elif notification_type == 'accepted':
            # Notify brand that creator accepted
            to_email = brand.user.email
            subject = f"{creator.display_name or creator.user.username} Accepted Your Collaboration"
            body = f"{creator.display_name or creator.user.username} has accepted your collaboration request!"

        elif notification_type == 'rejected':
            # Notify brand that creator rejected
            to_email = brand.user.email
            subject = f"Collaboration Request Update"
            body = f"{creator.display_name or creator.user.username} has declined your collaboration request."

        elif notification_type == 'completed':
            # Notify both parties
            # Send to brand
            email_service.send_email(
                subject=f"Collaboration Completed",
                recipients=brand.user.email,
                text_body=f"Your collaboration with {creator.display_name or creator.user.username} has been marked as completed."
            )
            # Send to creator
            to_email = creator.user.email
            subject = f"Collaboration Completed"
            body = f"Your collaboration with {brand.company_name} has been marked as completed."

        else:
            logger.warning(f"Unknown notification type: {notification_type}")
            return {'status': 'skipped', 'message': f'Unknown notification type: {notification_type}'}

        email_service.send_email(
            subject=subject,
            recipients=to_email,
            text_body=body
        )

        logger.info(f"Successfully sent {notification_type} notification for collaboration {collaboration_id}")
        return {
            'status': 'success',
            'collaboration_id': collaboration_id,
            'notification_type': notification_type,
            'to': to_email
        }

    except Exception as e:
        logger.error(f"Error sending collaboration notification: {str(e)}", exc_info=True)
        return {
            'status': 'error',
            'collaboration_id': collaboration_id,
            'message': str(e)
        }


@celery.task(name='app.tasks.email_tasks.send_booking_notification')
def send_booking_notification(booking_id, notification_type):
    """
    Send booking-related notification email.

    Args:
        booking_id: ID of the booking
        notification_type: Type of notification (new, confirmed, cancelled, etc.)

    Returns:
        dict: Send result
    """
    try:
        from app.models import Booking, CreatorProfile, BrandProfile

        logger.info(f"Sending {notification_type} notification for booking {booking_id}")

        booking = Booking.query.get(booking_id)
        if not booking:
            logger.error(f"Booking {booking_id} not found")
            return {'status': 'error', 'message': 'Booking not found'}

        creator = CreatorProfile.query.get(booking.creator_id)
        brand = BrandProfile.query.get(booking.brand_id)

        # Determine recipient and email content
        if notification_type == 'new':
            to_email = creator.user.email
            subject = f"New Booking from {brand.company_name}"
            body = f"You have a new booking request. Log in to review."

        elif notification_type == 'confirmed':
            to_email = brand.user.email
            subject = f"Booking Confirmed"
            body = f"Your booking has been confirmed!"

        elif notification_type == 'cancelled':
            # Notify both
            email_service.send_email(
                subject="Booking Cancelled",
                recipients=brand.user.email,
                text_body=f"Your booking has been cancelled."
            )
            to_email = creator.user.email
            subject = "Booking Cancelled"
            body = "A booking has been cancelled."

        else:
            logger.warning(f"Unknown notification type: {notification_type}")
            return {'status': 'skipped', 'message': f'Unknown notification type: {notification_type}'}

        email_service.send_email(
            subject=subject,
            recipients=to_email,
            text_body=body
        )

        logger.info(f"Successfully sent {notification_type} notification for booking {booking_id}")
        return {
            'status': 'success',
            'booking_id': booking_id,
            'notification_type': notification_type,
            'to': to_email
        }

    except Exception as e:
        logger.error(f"Error sending booking notification: {str(e)}", exc_info=True)
        return {
            'status': 'error',
            'booking_id': booking_id,
            'message': str(e)
        }
