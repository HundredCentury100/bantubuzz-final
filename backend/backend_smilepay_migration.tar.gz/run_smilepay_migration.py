"""
Run SmilePay transactions table migration
"""

import os
import sys

# Add parent directory to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app import create_app, db

def run_migration():
    """Execute SmilePay migration SQL"""
    app = create_app()

    with app.app_context():
        # Read migration file
        migration_file = os.path.join(
            os.path.dirname(__file__),
            'migrations',
            'create_smilepay_transactions.sql'
        )

        with open(migration_file, 'r') as f:
            sql = f.read()

        try:
            # Execute migration
            db.session.execute(sql)
            db.session.commit()
            print("✅ SmilePay transactions table created successfully!")
            print("✅ Added smilepay_order_reference columns to existing tables")
            return True

        except Exception as e:
            db.session.rollback()
            print(f"❌ Migration failed: {e}")
            return False

if __name__ == '__main__':
    success = run_migration()
    sys.exit(0 if success else 1)
