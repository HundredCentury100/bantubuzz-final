"""
Creator Platform Analytics Service
Fetches platform analytics data from ThunziAI API and calculates detailed metrics
"""
from typing import Dict, List, Optional
from datetime import datetime, timedelta
from flask import current_app
from statistics import mean

from app.models import ThunziAccount
from app.services.thunzi_service import thunzi_service


class CreatorAnalyticsService:
    """Service for fetching creator platform analytics from ThunziAI"""

    @staticmethod
    def get_creator_platform_analytics(creator_user_id: int) -> Dict:
        """
        Get analytics for all connected platforms for a creator from ThunziAI

        Uses the NEW ThunziAI endpoint (Mar 2026) that returns pre-calculated
        analytics averages including:
        - averageEngagementRate
        - averageSentimentScore
        - averageViews, averageReach, averageComments
        - averageLikes, averageShares, averageSaves

        Args:
            creator_user_id: The user_id of the creator

        Returns:
            Dictionary with platform analytics data from ThunziAI
        """
        try:
            # Get ThunziAI account for this creator
            thunzi_account = ThunziAccount.query.filter_by(user_id=creator_user_id).first()

            if not thunzi_account:
                return {
                    'success': True,
                    'has_platforms': False,
                    'platforms': [],
                    'verified_by': 'ThunziAI',
                    'last_updated': datetime.utcnow().isoformat()
                }

            # Login to ThunziAI with creator's credentials (password = email)
            login_success = thunzi_service.login(
                email=thunzi_account.thunzi_email,
                password=thunzi_account.thunzi_email
            )

            if not login_success:
                current_app.logger.error(
                    f"Failed to login to ThunziAI for creator {creator_user_id}"
                )
                return {
                    'success': False,
                    'has_platforms': False,
                    'platforms': [],
                    'error': 'Failed to authenticate with ThunziAI'
                }

            # Use NEW endpoint that returns pre-calculated analytics
            # This is much more efficient than manually calculating from posts
            thunzi_platforms = thunzi_service.get_creator_platforms(
                thunzi_account.bantubuzz_id
            )

            if not thunzi_platforms:
                return {
                    'success': True,
                    'has_platforms': False,
                    'platforms': [],
                    'verified_by': 'ThunziAI',
                    'last_updated': datetime.utcnow().isoformat()
                }

            # Format platforms with pre-calculated analytics from ThunziAI
            platform_analytics = []

            for thunzi_platform in thunzi_platforms:
                # Only include connected platforms with data
                if not thunzi_platform.get('isConnected'):
                    continue

                posts_count = thunzi_platform.get('posts', 0)
                if posts_count == 0:
                    continue  # Skip platforms with no posts

                # Format platform analytics with pre-calculated averages
                analytics = CreatorAnalyticsService._format_platform_analytics(
                    thunzi_platform
                )

                if analytics:
                    platform_analytics.append(analytics)

            return {
                'success': True,
                'has_platforms': len(platform_analytics) > 0,
                'platforms': platform_analytics,
                'verified_by': 'ThunziAI',
                'last_updated': datetime.utcnow().isoformat()
            }

        except Exception as e:
            current_app.logger.error(
                f"Error getting creator platform analytics: {str(e)}"
            )
            return {
                'success': False,
                'has_platforms': False,
                'platforms': [],
                'error': str(e)
            }

    @staticmethod
    def _format_platform_analytics(thunzi_platform: Dict) -> Optional[Dict]:
        """
        Format platform analytics from ThunziAI's pre-calculated data (NEW - Mar 2026)

        ThunziAI now provides pre-calculated averages, so we don't need to manually
        calculate from individual posts. This is much more efficient and accurate.

        Args:
            thunzi_platform: Platform data from ThunziAI API with pre-calculated averages

        Returns:
            Formatted analytics dictionary or None if invalid
        """
        try:
            platform_name = thunzi_platform.get('platform', '').lower()
            account_name = thunzi_platform.get('accountName', '')
            followers = thunzi_platform.get('followers', 0)
            posts = thunzi_platform.get('posts', 0)

            # Extract pre-calculated averages from ThunziAI (NEW fields)
            avg_engagement_rate = thunzi_platform.get('averageEngagementRate', 0)
            avg_sentiment_score = thunzi_platform.get('averageSentimentScore', 0)
            avg_views = thunzi_platform.get('averageViews', 0)
            avg_reach = thunzi_platform.get('averageReach', 0)
            avg_comments = thunzi_platform.get('averageComments', 0)
            avg_likes = thunzi_platform.get('averageLikes', 0)
            avg_shares = thunzi_platform.get('averageShares', 0)
            avg_saves = thunzi_platform.get('averageSaves', 0)

            # Base analytics structure
            analytics = {
                'platform': platform_name,
                'account_name': account_name,
                'account_id': thunzi_platform.get('accountId'),
                'profile_url': thunzi_platform.get('profileUrl'),
                'followers': followers,
                'total_posts': posts,
                'last_synced': thunzi_platform.get('lastSyncedAt'),
                'has_data': posts > 0
            }

            # Format platform-specific metrics using pre-calculated averages
            if platform_name == 'youtube':
                analytics['metrics'] = {
                    'subscribers': followers,
                    'total_posts': posts,
                    'avg_engagement_rate': round(float(avg_engagement_rate or 0), 2),
                    'avg_sentiment_score': round(float(avg_sentiment_score or 0), 2),
                    'avg_views': int(avg_views or 0),
                    'avg_comments': int(avg_comments or 0),
                    'avg_likes': int(avg_likes or 0),
                    'avg_shares': int(avg_shares or 0)
                }
            elif platform_name == 'facebook':
                analytics['metrics'] = {
                    'followers': followers,
                    'total_posts': posts,
                    'avg_engagement_rate': round(float(avg_engagement_rate or 0), 2),
                    'avg_sentiment_score': round(float(avg_sentiment_score or 0), 2),
                    'avg_reach': int(avg_reach or 0),
                    'avg_comments': int(avg_comments or 0),
                    'avg_likes': int(avg_likes or 0),
                    'avg_shares': int(avg_shares or 0)
                }
            elif platform_name == 'instagram':
                analytics['metrics'] = {
                    'followers': followers,
                    'total_posts': posts,
                    'avg_engagement_rate': round(float(avg_engagement_rate or 0), 2),
                    'avg_sentiment_score': round(float(avg_sentiment_score or 0), 2),
                    'avg_reach': int(avg_reach or 0),
                    'avg_comments': int(avg_comments or 0),
                    'avg_likes': int(avg_likes or 0),
                    'avg_shares': int(avg_shares or 0),
                    'avg_saves': int(avg_saves or 0)
                }
            elif platform_name == 'tiktok':
                analytics['metrics'] = {
                    'followers': followers,
                    'total_posts': posts,
                    'avg_engagement_rate': round(float(avg_engagement_rate or 0), 2),
                    'avg_sentiment_score': round(float(avg_sentiment_score or 0), 2),
                    'avg_views': int(avg_views or 0),
                    'avg_comments': int(avg_comments or 0),
                    'avg_likes': int(avg_likes or 0),
                    'avg_shares': int(avg_shares or 0),
                    'avg_saves': int(avg_saves or 0)
                }
            else:
                # Generic platform metrics
                analytics['metrics'] = {
                    'followers': followers,
                    'total_posts': posts,
                    'avg_engagement_rate': round(float(avg_engagement_rate or 0), 2),
                    'avg_sentiment_score': round(float(avg_sentiment_score or 0), 2),
                    'avg_reach': int(avg_reach or 0),
                    'avg_comments': int(avg_comments or 0),
                    'avg_likes': int(avg_likes or 0),
                    'avg_shares': int(avg_shares or 0),
                    'avg_saves': int(avg_saves or 0)
                }

            return analytics

        except Exception as e:
            current_app.logger.error(
                f"Error formatting platform analytics: {str(e)}"
            )
            return None
