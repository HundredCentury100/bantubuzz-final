"""
Campaign Invitations Routes
Handles inviting creators to campaigns
"""
from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from app import db
from app.models import (
    User, Campaign, CampaignInvitation, CreatorProfile,
    Notification, CampaignApplication, CampaignProposal
)
from datetime import datetime

bp = Blueprint('campaign_invitations', __name__, url_prefix='/api/campaign-invitations')


@bp.route('/invite', methods=['POST'])
@jwt_required()
def send_invitation():
    """
    Send invitation(s) to creator(s) for a campaign
    Body: {
        campaign_id: int,
        creator_ids: [int],  # List of creator user IDs
        invitation_type: 'invite_to_apply' | 'invite_to_join',
        message: str (optional),
        expires_in_days: int (optional, default: 7)
    }
    """
    try:
        user_id = int(get_jwt_identity())
        user = User.query.get(user_id)

        if not user or user.user_type != 'brand':
            return jsonify({'error': 'Unauthorized: Brand access only'}), 403

        data = request.get_json()
        campaign_id = data.get('campaign_id')
        creator_ids = data.get('creator_ids', [])
        invitation_type = data.get('invitation_type', 'invite_to_apply')
        message = data.get('message')
        expires_in_days = data.get('expires_in_days', 7)

        # Validate
        if not campaign_id or not creator_ids:
            return jsonify({'error': 'campaign_id and creator_ids are required'}), 400

        if invitation_type not in ['invite_to_apply', 'invite_to_join']:
            return jsonify({'error': 'Invalid invitation_type'}), 400

        # Verify campaign ownership
        campaign = Campaign.query.get(campaign_id)
        if not campaign:
            return jsonify({'error': 'Campaign not found'}), 404

        if campaign.brand_user_id != user_id:
            return jsonify({'error': 'Unauthorized: You do not own this campaign'}), 403

        # Send invitations
        invitations_sent = []
        invitations_failed = []

        for creator_id in creator_ids:
            try:
                # Verify creator exists
                creator = User.query.get(creator_id)
                if not creator or creator.user_type != 'creator':
                    invitations_failed.append({
                        'creator_id': creator_id,
                        'reason': 'Creator not found or invalid user type'
                    })
                    continue

                # Create invitation
                invitation = CampaignInvitation.create_invitation(
                    campaign_id=campaign_id,
                    creator_user_id=creator_id,
                    invited_by_user_id=user_id,
                    invitation_type=invitation_type,
                    message=message,
                    expires_in_days=expires_in_days
                )

                if not invitation:
                    invitations_failed.append({
                        'creator_id': creator_id,
                        'reason': 'Creator already has an active invitation for this campaign'
                    })
                    continue

                # Create notification for creator
                notification = Notification(
                    user_id=creator_id,
                    type='campaign_invitation',
                    title=f'Campaign Invitation: {campaign.title}',
                    message=f'You have been invited to {"apply for" if invitation_type == "invite_to_apply" else "join"} the campaign "{campaign.title}"',
                    related_id=invitation.id,
                    link=f'/campaigns/{campaign_id}'
                )
                db.session.add(notification)

                # Send email notification
                from app.services.email_service import send_campaign_invitation_email
                send_campaign_invitation_email(
                    creator_email=creator.email,
                    creator_name=CreatorProfile.query.filter_by(user_id=creator_id).first().display_name,
                    campaign_title=campaign.title,
                    brand_name=user.brand_profile.company_name if hasattr(user, 'brand_profile') else user.email,
                    invitation_type=invitation_type,
                    message=message,
                    campaign_url=f'{request.host_url}campaigns/{campaign_id}'
                )

                invitations_sent.append(invitation.to_dict())

            except Exception as e:
                invitations_failed.append({
                    'creator_id': creator_id,
                    'reason': str(e)
                })

        db.session.commit()

        return jsonify({
            'message': f'Sent {len(invitations_sent)} invitation(s)',
            'invitations_sent': invitations_sent,
            'invitations_failed': invitations_failed
        }), 200

    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500


@bp.route('/creator/pending', methods=['GET'])
@jwt_required()
def get_creator_pending_invitations():
    """Get all pending invitations for the logged-in creator"""
    try:
        user_id = int(get_jwt_identity())
        user = User.query.get(user_id)

        if not user or user.user_type != 'creator':
            return jsonify({'error': 'Unauthorized: Creator access only'}), 403

        invitations = CampaignInvitation.get_pending_invitations_for_creator(user_id)

        return jsonify({
            'invitations': [inv.to_dict() for inv in invitations],
            'count': len(invitations)
        }), 200

    except Exception as e:
        return jsonify({'error': str(e)}), 500


@bp.route('/campaign/<int:campaign_id>', methods=['GET'])
@jwt_required()
def get_campaign_invitations(campaign_id):
    """Get all invitations for a campaign (brand only)"""
    try:
        user_id = int(get_jwt_identity())
        user = User.query.get(user_id)

        if not user or user.user_type != 'brand':
            return jsonify({'error': 'Unauthorized: Brand access only'}), 403

        # Verify campaign ownership
        campaign = Campaign.query.get(campaign_id)
        if not campaign:
            return jsonify({'error': 'Campaign not found'}), 404

        if campaign.brand_user_id != user_id:
            return jsonify({'error': 'Unauthorized: You do not own this campaign'}), 403

        # Get invitations with optional status filter
        status = request.args.get('status')
        invitations = CampaignInvitation.get_invitations_for_campaign(campaign_id, status)

        return jsonify({
            'invitations': [inv.to_dict() for inv in invitations],
            'count': len(invitations)
        }), 200

    except Exception as e:
        return jsonify({'error': str(e)}), 500


@bp.route('/<int:invitation_id>/accept', methods=['POST'])
@jwt_required()
def accept_invitation(invitation_id):
    """
    Creator accepts an invitation
    For 'invite_to_apply': Redirects to application/proposal flow
    For 'invite_to_join': Directly creates collaboration
    """
    try:
        user_id = int(get_jwt_identity())
        user = User.query.get(user_id)

        if not user or user.user_type != 'creator':
            return jsonify({'error': 'Unauthorized: Creator access only'}), 403

        invitation = CampaignInvitation.query.get(invitation_id)
        if not invitation:
            return jsonify({'error': 'Invitation not found'}), 404

        if invitation.creator_user_id != user_id:
            return jsonify({'error': 'Unauthorized: This invitation is not for you'}), 403

        if invitation.status != 'pending':
            return jsonify({'error': f'Invitation already {invitation.status}'}), 400

        if invitation.is_expired:
            invitation.expire()
            return jsonify({'error': 'Invitation has expired'}), 400

        # Accept the invitation
        invitation.accept()

        # Create notification for brand
        campaign = Campaign.query.get(invitation.campaign_id)
        notification = Notification(
            user_id=campaign.brand_user_id,
            type='invitation_accepted',
            title='Invitation Accepted',
            message=f'{user.creator_profile.display_name if hasattr(user, "creator_profile") else user.email} accepted your invitation for "{campaign.title}"',
            related_id=invitation_id,
            link=f'/campaigns/{campaign.id}'
        )
        db.session.add(notification)
        db.session.commit()

        response_data = {
            'message': 'Invitation accepted',
            'invitation': invitation.to_dict(),
            'next_step': None
        }

        if invitation.invitation_type == 'invite_to_apply':
            # Creator should apply/propose to the campaign
            response_data['next_step'] = 'apply'
            response_data['redirect_url'] = f'/campaigns/{campaign.id}'

        elif invitation.invitation_type == 'invite_to_join':
            # Auto-create application/proposal
            # Check if creator already applied
            existing_application = CampaignApplication.query.filter_by(
                campaign_id=campaign.id,
                creator_user_id=user_id
            ).first()

            if not existing_application:
                # Create auto-approved application
                application = CampaignApplication(
                    campaign_id=campaign.id,
                    creator_user_id=user_id,
                    status='approved',
                    applied_at=datetime.utcnow(),
                    reviewed_at=datetime.utcnow()
                )
                db.session.add(application)
                db.session.commit()

                response_data['application_id'] = application.id

            response_data['next_step'] = 'submit_proposal'
            response_data['redirect_url'] = f'/campaigns/{campaign.id}/propose'

        return jsonify(response_data), 200

    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500


@bp.route('/<int:invitation_id>/decline', methods=['POST'])
@jwt_required()
def decline_invitation(invitation_id):
    """Creator declines an invitation"""
    try:
        user_id = int(get_jwt_identity())
        user = User.query.get(user_id)

        if not user or user.user_type != 'creator':
            return jsonify({'error': 'Unauthorized: Creator access only'}), 403

        invitation = CampaignInvitation.query.get(invitation_id)
        if not invitation:
            return jsonify({'error': 'Invitation not found'}), 404

        if invitation.creator_user_id != user_id:
            return jsonify({'error': 'Unauthorized: This invitation is not for you'}), 403

        if invitation.status != 'pending':
            return jsonify({'error': f'Invitation already {invitation.status}'}), 400

        # Decline the invitation
        invitation.decline()

        # Create notification for brand
        campaign = Campaign.query.get(invitation.campaign_id)
        notification = Notification(
            user_id=campaign.brand_user_id,
            type='invitation_declined',
            title='Invitation Declined',
            message=f'{user.creator_profile.display_name if hasattr(user, "creator_profile") else user.email} declined your invitation for "{campaign.title}"',
            related_id=invitation_id,
            link=f'/campaigns/{campaign.id}'
        )
        db.session.add(notification)
        db.session.commit()

        return jsonify({
            'message': 'Invitation declined',
            'invitation': invitation.to_dict()
        }), 200

    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500


@bp.route('/<int:invitation_id>', methods=['DELETE'])
@jwt_required()
def cancel_invitation(invitation_id):
    """Brand cancels an invitation"""
    try:
        user_id = int(get_jwt_identity())
        user = User.query.get(user_id)

        if not user or user.user_type != 'brand':
            return jsonify({'error': 'Unauthorized: Brand access only'}), 403

        invitation = CampaignInvitation.query.get(invitation_id)
        if not invitation:
            return jsonify({'error': 'Invitation not found'}), 404

        if invitation.invited_by_user_id != user_id:
            return jsonify({'error': 'Unauthorized: You did not send this invitation'}), 403

        # Delete the invitation
        db.session.delete(invitation)
        db.session.commit()

        return jsonify({'message': 'Invitation cancelled'}), 200

    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500
